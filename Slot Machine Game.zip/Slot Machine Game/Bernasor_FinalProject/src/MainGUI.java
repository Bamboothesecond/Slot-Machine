
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import static javax.swing.SwingConstants.CENTER;

public class MainGUI extends JFrame {

    private JLabel betLabel, credittitleLabel, creditLabel;
    private JButton btn_AddCoin, btn_Spin, btn_Sub, btn_AddBet, btn_Reset, btn_Stat, btn_Withdraw;

    //Declaration of the variables
    private static JLabel title;
    public static JLabel reel1, reel2, reel3;
    private final Container contentPane;
    private final SlotMachine slotMachine;
    private static int index, wins, losses, noOfGames;
    private int profit, loss;
    private static double statValue, average;
    public static boolean flag = true, reelClickable = true;
    private ArrayList<ArrayList<Symbol>> reelImages;
    private GridBagConstraints gridBagConstraints;

    //Declaration of the Constructor
    public MainGUI(SlotMachine slotMachine) {
        this.slotMachine = slotMachine;
        contentPane = getContentPane();
        contentPane.add(titlePanel(), BorderLayout.NORTH);
        contentPane.add(viewPanel(), BorderLayout.CENTER);
        contentPane.add(controllerPanel(), BorderLayout.SOUTH);
        startup();
    }

    //Setting up the public Getters
    public static int getWins() {
        return wins;
    }

    public static int getLosses() {
        return losses;
    }

    public static double getAverage() {
        return average;
    }

    //Setting up Different types of JPanels so we can include them inside a ContentPane
    private JComponent titlePanel() {
        loadFont();
        JPanel titlePanel = new JPanel();
        title = new JLabel();
        title.setText("Spin Of Fortune");
        title.setFont(new Font("New Athletic M54", 1, 48));
        title.setForeground(Color.cyan);
        titlePanel.add(title);
        titlePanel.setBackground(Color.BLACK);
        titlePanel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
        GridBagLayout jPanel6Layout = new GridBagLayout();
        jPanel6Layout.columnWidths = new int[]{620};
        jPanel6Layout.rowHeights = new int[]{100};
        titlePanel.setLayout(jPanel6Layout);
        titlePanel.add(title, new GridBagConstraints());
        return titlePanel;
    }

    private JComponent viewPanel() {
        loadFont();
        JPanel viewPanel = new JPanel();
        viewPanel.setBackground(new Color(51, 255, 153));
        viewPanel.setPreferredSize(new Dimension(0, 200));
        GridBagLayout jPanel1Layout = new GridBagLayout();
        jPanel1Layout.columnWidths = new int[]{620};
        jPanel1Layout.rowHeights = new int[]{200};
        viewPanel.setLayout(jPanel1Layout);

        JPanel slotPanel = new JPanel();
        slotPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
        slotPanel.setMaximumSize(new Dimension(620, 200));
        slotPanel.setMinimumSize(new Dimension(620, 200));
        slotPanel.setPreferredSize(new Dimension(620, 200));
        GridBagLayout jPanel3Layout2 = new GridBagLayout();
        jPanel3Layout2.columnWidths = new int[]{0, 5, 0, 5, 0};
        jPanel3Layout2.rowHeights = new int[]{0};
        slotPanel.setLayout(jPanel3Layout2);

        JPanel reel1Panel = new JPanel();
        reel1Panel.setBackground(new Color(204, 204, 204));
        reel1Panel.setBorder(new LineBorder(new Color(51, 51, 51), 5, true));
        reel1Panel.setMaximumSize(new Dimension(175, 175));
        reel1Panel.setMinimumSize(new Dimension(175, 175));
        reel1Panel.setPreferredSize(new Dimension(175, 175));
        GridBagLayout jPanel4Layout2 = new GridBagLayout();
        jPanel4Layout2.columnWidths = new int[]{0};
        jPanel4Layout2.rowHeights = new int[]{0};
        reel1Panel.setLayout(jPanel4Layout2);

        reel1 = new JLabel();
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        reel1Panel.add(reel1, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 15);
        slotPanel.add(reel1Panel, gridBagConstraints);

        JPanel reel2Panel = new JPanel();
        reel2Panel.setBackground(new Color(204, 204, 204));
        reel2Panel.setBorder(new LineBorder(new Color(51, 51, 51), 5, true));
        reel2Panel.setMaximumSize(new Dimension(175, 175));
        reel2Panel.setMinimumSize(new Dimension(175, 175));
        reel2Panel.setPreferredSize(new Dimension(175, 175));
        GridBagLayout jPanel3Layout3 = new GridBagLayout();
        jPanel3Layout3.columnWidths = new int[]{175};
        jPanel3Layout3.rowHeights = new int[]{175};
        reel2Panel.setLayout(jPanel3Layout3);

        reel2 = new JLabel();
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        reel2Panel.add(reel2, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 15);
        slotPanel.add(reel2Panel, gridBagConstraints);

        JPanel reel3Panel = new JPanel();
        reel3Panel.setBackground(new Color(204, 204, 204));
        reel3Panel.setBorder(new LineBorder(new Color(51, 51, 51), 5, true));
        reel3Panel.setMaximumSize(new Dimension(175, 175));
        reel3Panel.setMinimumSize(new Dimension(175, 175));
        reel3Panel.setPreferredSize(new Dimension(175, 175));
        GridBagLayout jPanel4Layout3 = new GridBagLayout();
        jPanel4Layout3.columnWidths = new int[]{175};
        jPanel4Layout3.rowHeights = new int[]{175};
        reel3Panel.setLayout(jPanel4Layout3);

        reel3 = new JLabel();
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        reel3Panel.add(reel3, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 15);
        slotPanel.add(reel3Panel, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        viewPanel.add(slotPanel, gridBagConstraints);

        JPanel spinPanel = new JPanel();
        spinPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
        spinPanel.setMinimumSize(new Dimension(100, 200));
        spinPanel.setPreferredSize(new Dimension(200, 100));
        GridBagLayout jPanel7Layout = new GridBagLayout();
        jPanel7Layout.columnWidths = new int[]{0};
        jPanel7Layout.rowHeights = new int[]{0};
        spinPanel.setLayout(jPanel7Layout);

        JPanel spinholePanel = new JPanel();
        spinholePanel.setBackground(new Color(0, 0, 0));
        spinholePanel.setPreferredSize(new Dimension(50, 150));
        GridBagLayout jPanel4Layout1 = new GridBagLayout();
        jPanel4Layout1.columnWidths = new int[]{50};
        jPanel4Layout1.rowHeights = new int[]{150};
        spinholePanel.setLayout(jPanel4Layout1);
        btn_Spin = new JButton();
        btn_Spin.setIcon(new ImageIcon(getClass().getResource("icon/lever0o.png")));
        btn_Spin.setBorderPainted(false);
        btn_Spin.setContentAreaFilled(false);

        btn_Spin.setFocusPainted(false);
        btn_Spin.setDisabledIcon(new ImageIcon(getClass().getResource("icon/lever10.png")));
        btn_Spin.setFocusPainted(false);
        btn_Spin.setMaximumSize(new Dimension(50, 101));
        btn_Spin.setMinimumSize(new Dimension(50, 101));
        btn_Spin.setPreferredSize(new Dimension(50, 101));
        btn_Spin.setPressedIcon(new ImageIcon(getClass().getResource("icon/off.png")));
        spinholePanel.add(btn_Spin, new GridBagConstraints());

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.gridheight = java.awt.GridBagConstraints.REMAINDER;
        spinPanel.add(spinholePanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        viewPanel.add(spinPanel, gridBagConstraints);

        btn_Spin.addActionListener((ActionEvent e) -> {
            spinButtonVisibility();
            turnOffOtherButtonVisibility();
            spinBtnPressed();
            reelClickable = true;
        });

        reel1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                flag = false;
                spinButtonVisibility();
                turnOnOtherButtonVisibility();
                calculateResult();
            }
        });

        reel2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                flag = false;
                spinButtonVisibility();
                turnOnOtherButtonVisibility();
                calculateResult();
            }
        });

        reel3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                flag = false;
                spinButtonVisibility();
                turnOnOtherButtonVisibility();
                calculateResult();
            }
        });

        return viewPanel;
    }

    private JComponent controllerPanel() {
        loadFont();
        JPanel controllerPanel = new JPanel();
        controllerPanel.setBackground(new Color(0, 0, 204));
        controllerPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
        controllerPanel.setMaximumSize(new Dimension(720, 268));
        controllerPanel.setMinimumSize(new Dimension(720, 268));
        controllerPanel.setPreferredSize(new Dimension(720, 268));
        GridBagLayout jPanel2Layout1 = new GridBagLayout();
        jPanel2Layout1.columnWidths = new int[]{0, 5, 0};
        jPanel2Layout1.rowHeights = new int[]{0};
        controllerPanel.setLayout(jPanel2Layout1);

        JPanel betPanel = new JPanel();
        betPanel.setBackground(new Color(51, 51, 51));
        betPanel.setMaximumSize(new Dimension(360, 268));
        betPanel.setMinimumSize(new Dimension(360, 268));
        betPanel.setPreferredSize(new Dimension(360, 268));
        GridBagLayout jPanel4Layout4 = new GridBagLayout();
        jPanel4Layout4.columnWidths = new int[]{0};
        jPanel4Layout4.rowHeights = new int[]{0, 0, 0};
        betPanel.setLayout(jPanel4Layout4);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        JPanel betvaluePanel = new JPanel();
        betvaluePanel.setBackground(new Color(51, 51, 51));
        betvaluePanel.setMaximumSize(new Dimension(360, 134));
        betvaluePanel.setMinimumSize(new Dimension(360, 134));
        betvaluePanel.setOpaque(false);
        betvaluePanel.setPreferredSize(new Dimension(360, 134));
        GridBagLayout jPanel1Layout2 = new GridBagLayout();
        jPanel1Layout2.columnWidths = new int[]{0, 5};
        jPanel1Layout2.rowHeights = new int[]{268};
        betvaluePanel.setLayout(jPanel1Layout2);
        btn_Sub = new JButton();
        btn_Sub.setBackground(new Color(255, 255, 255));
        btn_Sub.setFont(new Font("Tahoma", 1, 24));
        btn_Sub.setForeground(new Color(0, 255, 255));
        btn_Sub.setText("<");
        btn_Sub.setFocusPainted(false);
        btn_Sub.setBorder(null);
        btn_Sub.setBorderPainted(false);
        btn_Sub.setContentAreaFilled(false);
        btn_Sub.setMaximumSize(new Dimension(75, 25));
        btn_Sub.setMinimumSize(new Dimension(75, 25));
        btn_Sub.setPreferredSize(new Dimension(75, 25));
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        betvaluePanel.add(btn_Sub, gridBagConstraints);
        betLabel = new JLabel();
        if (slotMachine.getCurrentBet() < 10) {
            betLabel.setText(" 0" + slotMachine.getCurrentBet() + " ");
        } else {
            betLabel.setText(" " + slotMachine.getCurrentBet() + " ");
        }
        betLabel.setBackground(new Color(51, 51, 51));
        betLabel.setFont(new Font("Tahoma", 1, 24));
        betLabel.setForeground(new Color(0, 255, 255));
        betLabel.setHorizontalAlignment(CENTER);
        betLabel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED));
        betLabel.setMaximumSize(new Dimension(75, 75));
        betLabel.setMinimumSize(new Dimension(75, 75));
        betLabel.setPreferredSize(new Dimension(75, 75));
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        betvaluePanel.add(betLabel, gridBagConstraints);
        btn_AddBet = new JButton();
        btn_AddBet.setBackground(new Color(0, 0, 0));
        btn_AddBet.setFont(new Font("Tahoma", 1, 24));
        btn_AddBet.setForeground(new Color(0, 255, 255));
        btn_AddBet.setText(">");
        btn_AddBet.setFocusPainted(false);
        btn_AddBet.setBorder(null);
        btn_AddBet.setBorderPainted(false);
        btn_AddBet.setContentAreaFilled(false);
        btn_AddBet.setMaximumSize(new Dimension(75, 25));
        btn_AddBet.setMinimumSize(new Dimension(75, 25));
        btn_AddBet.setPreferredSize(new Dimension(75, 25));
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        betvaluePanel.add(btn_AddBet, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        betPanel.add(betvaluePanel, gridBagConstraints);

        JPanel betresetPanel = new JPanel();
        betresetPanel.setBackground(new Color(51, 51, 51));
        betresetPanel.setMaximumSize(new Dimension(360, 134));
        betresetPanel.setMinimumSize(new Dimension(360, 134));
        betresetPanel.setPreferredSize(new Dimension(360, 134));
        GridBagLayout jPanel2Layout3 = new GridBagLayout();
        jPanel2Layout3.columnWidths = new int[]{360};
        jPanel2Layout3.rowHeights = new int[]{100};
        betresetPanel.setLayout(jPanel2Layout3);
        btn_Reset = new JButton();
        btn_Reset.setBackground(new Color(0, 0, 0));
        btn_Reset.setFont(new Font("Tahoma", 1, 24));
        btn_Reset.setForeground(new Color(0, 255, 255));
        btn_Reset.setText("Reset");
        btn_Reset.setFocusPainted(false);
        btn_Reset.setBorder(null);
        btn_Reset.setBorderPainted(false);
        btn_Reset.setContentAreaFilled(false);
        btn_Reset.setMaximumSize(new Dimension(225, 75));
        btn_Reset.setMinimumSize(new Dimension(225, 75));
        btn_Reset.setPreferredSize(new Dimension(225, 75));
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        betresetPanel.add(btn_Reset, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        betPanel.add(betresetPanel, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        controllerPanel.add(betPanel, gridBagConstraints);

        JPanel creditPanel = new JPanel();
        creditPanel.setBackground(new Color(204, 255, 153));
        creditPanel.setMaximumSize(new Dimension(360, 268));
        creditPanel.setMinimumSize(new Dimension(360, 268));
        creditPanel.setPreferredSize(new Dimension(360, 268));
        GridBagLayout jPanel3Layout5 = new GridBagLayout();
        jPanel3Layout5.columnWidths = new int[]{0};
        jPanel3Layout5.rowHeights = new int[]{0, 0, 0, 0, 0};
        creditPanel.setLayout(jPanel3Layout5);

        JPanel playerbalPanel = new JPanel();
        playerbalPanel.setBackground(new Color(255, 153, 153));
        playerbalPanel.setMaximumSize(new Dimension(360, 134));
        playerbalPanel.setMinimumSize(new Dimension(360, 134));
        playerbalPanel.setPreferredSize(new Dimension(360, 134));
        GridBagLayout jPanel1Layout3 = new GridBagLayout();
        jPanel1Layout3.columnWidths = new int[]{0};
        jPanel1Layout3.rowHeights = new int[]{0};
        playerbalPanel.setLayout(jPanel1Layout3);

        JPanel jPanel4 = new JPanel();
        jPanel4.setBackground(new Color(51, 51, 51));
        jPanel4.setMaximumSize(new Dimension(100, 134));
        jPanel4.setMinimumSize(new Dimension(100, 134));
        jPanel4.setPreferredSize(new Dimension(100, 134));
        GridBagLayout jPanel4Layout5 = new GridBagLayout();
        jPanel4Layout5.columnWidths = new int[]{100};
        jPanel4Layout5.rowHeights = new int[]{100};
        jPanel4.setLayout(jPanel4Layout5);
        credittitleLabel = new JLabel();
        credittitleLabel.setFont(new Font("Tahoma", 1, 24));
        credittitleLabel.setForeground(new Color(0, 255, 255));
        credittitleLabel.setText("CREDIT");
        jPanel4.add(credittitleLabel, new GridBagConstraints());

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        playerbalPanel.add(jPanel4, gridBagConstraints);

        JPanel jPanel5 = new JPanel();
        jPanel5.setBackground(new Color(51, 51, 51));
        jPanel5.setMaximumSize(new Dimension(260, 134));
        jPanel5.setMinimumSize(new Dimension(260, 134));
        jPanel5.setPreferredSize(new Dimension(260, 134));
        GridBagLayout jPanel5Layout1 = new GridBagLayout();
        jPanel5Layout1.columnWidths = new int[]{260};
        jPanel5Layout1.rowHeights = new int[]{100};
        jPanel5.setLayout(jPanel5Layout1);

        JPanel jPanel6 = new JPanel();
        jPanel6.setBackground(new Color(0, 0, 0));
        GridBagLayout jPanel6Layout1 = new GridBagLayout();
        jPanel6Layout1.columnWidths = new int[]{200};
        jPanel6Layout1.rowHeights = new int[]{50};
        jPanel6.setLayout(jPanel6Layout1);

        creditLabel = new JLabel();
        creditLabel.setText("00");
        if (slotMachine.getRemCredit() < 10) {
            creditLabel.setText(" 0" + slotMachine.getRemCredit() + " ");
        } else {
            creditLabel.setText(" " + slotMachine.getRemCredit() + " ");
        }
        creditLabel.setFont(new Font("Tahoma", 1, 24));
        creditLabel.setForeground(new Color(0, 255, 255));
        jPanel6.add(creditLabel, new GridBagConstraints());

        jPanel5.add(jPanel6, new GridBagConstraints());

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        playerbalPanel.add(jPanel5, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        creditPanel.add(playerbalPanel, gridBagConstraints);

        JPanel jPanel2 = new JPanel();
        jPanel2.setBackground(new Color(153, 255, 153));
        jPanel2.setMaximumSize(new Dimension(360, 134));
        jPanel2.setMinimumSize(new Dimension(360, 134));
        jPanel2.setPreferredSize(new Dimension(360, 134));
        GridBagLayout jPanel2Layout4 = new GridBagLayout();
        jPanel2Layout4.columnWidths = new int[]{0, 0};
        jPanel2Layout4.rowHeights = new int[]{0};
        jPanel2.setLayout(jPanel2Layout4);

        JPanel jPanel1 = new JPanel();
        jPanel1.setBackground(new Color(51, 51, 51));
        jPanel1.setForeground(new Color(0, 255, 255));
        jPanel1.setMaximumSize(new Dimension(260, 134));
        jPanel1.setMinimumSize(new Dimension(260, 134));
        jPanel1.setName("");
        jPanel1.setPreferredSize(new Dimension(260, 134));
        GridBagLayout jPanel1Layout4 = new GridBagLayout();
        jPanel1Layout4.columnWidths = new int[]{100};
        jPanel1Layout4.rowHeights = new int[]{134};
        jPanel1.setLayout(jPanel1Layout4);

        btn_Stat = new JButton();
        btn_Stat.setFont(new Font("Tahoma", 1, 14));
        btn_Stat.setForeground(new Color(0, 255, 255));
        btn_Stat.setText("Statistics");
        btn_Stat.setBorder(null);
        btn_Stat.setBorderPainted(false);
        btn_Stat.setContentAreaFilled(false);
        btn_Stat.setMaximumSize(new Dimension(100, 100));
        btn_Stat.setMinimumSize(new Dimension(100, 100));
        btn_Stat.setPreferredSize(new Dimension(100, 100));
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.insets = new Insets(0, 0, 0, 15);
        jPanel1.add(btn_Stat, gridBagConstraints);

        btn_Withdraw = new JButton();
        btn_Withdraw.setFont(new Font("Tahoma", 1, 14));
        btn_Withdraw.setForeground(new Color(0, 255, 255));
        btn_Withdraw.setText("Withdraw");
        btn_Withdraw.setBorder(null);
        btn_Withdraw.setBorderPainted(false);
        btn_Withdraw.setContentAreaFilled(false);
        btn_Withdraw.setFocusPainted(false);
        btn_Withdraw.setMaximumSize(new Dimension(100, 100));
        btn_Withdraw.setMinimumSize(new Dimension(100, 100));
        btn_Withdraw.setPreferredSize(new Dimension(100, 100));
        jPanel1.add(btn_Withdraw, new GridBagConstraints());

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        jPanel2.add(jPanel1, gridBagConstraints);

        JPanel jPanel3 = new JPanel();
        jPanel3.setBackground(new Color(51, 51, 51));
        GridBagLayout jPanel3Layout6 = new GridBagLayout();
        jPanel3Layout6.columnWidths = new int[]{100};
        jPanel3Layout6.rowHeights = new int[]{134};
        jPanel3.setLayout(jPanel3Layout6);

        JPanel jPanel7 = new JPanel();
        jPanel7.setBackground(new Color(0, 0, 0));
        jPanel7.setPreferredSize(new Dimension(25, 75));
        GridBagLayout jPanel7Layout1 = new GridBagLayout();
        jPanel7Layout1.columnWidths = new int[]{50};
        jPanel7Layout1.rowHeights = new int[]{75};
        jPanel7.setLayout(jPanel7Layout1);

        btn_AddCoin = new JButton();
        btn_AddCoin.setBackground(new Color(0, 0, 0));
        btn_AddCoin.setBorder(BorderFactory.createLineBorder(new Color(204, 204, 204), 3));
        btn_AddCoin.setContentAreaFilled(false);
        btn_AddCoin.setMaximumSize(new Dimension(25, 75));
        btn_AddCoin.setMinimumSize(new Dimension(25, 75));
        btn_AddCoin.setPreferredSize(new Dimension(25, 75));
        jPanel7.add(btn_AddCoin, new GridBagConstraints());

        btn_AddCoin.addActionListener((ActionEvent e) -> {
            addCoinBtnPressed();
        });

        btn_AddBet.addActionListener((ActionEvent e) -> {
            betAddBtnPressed();
        });

        btn_Sub.addActionListener((ActionEvent e) -> {
            betSubBtnPressed();
        });

        btn_Reset.addActionListener((ActionEvent e) -> {
            slotMachine.setRemCredit(0);
            noOfGames = 0;
            wins = 0;
            loss = 0;
            resetBtnPressed();
        });
        
        btn_Withdraw.addActionListener((ActionEvent e) -> {
            slotMachine.setRemCredit(0);
            withdrawBtnPressed();
        });

        btn_Stat.addActionListener((ActionEvent e) -> {
            StatsGUI stats = new StatsGUI();
            stats.setTitle("Statistics");
            stats.setSize(610, 507);
            stats.setMinimumSize(new Dimension(610, 507));
            stats.setVisible(true);
        });
        jPanel3.add(jPanel7, new GridBagConstraints());

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        jPanel2.add(jPanel3, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        creditPanel.add(jPanel2, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        controllerPanel.add(creditPanel, gridBagConstraints);

        return controllerPanel;
    }


    private void startup() {

        reelImages = new ArrayList<ArrayList<Symbol>>();
        for (int x = 0; x < 3; x++) {
            reelImages.add(slotMachine.getReel(x));
        }
        reel1.setIcon(reelImages.get(0).get(index).getImage());
        reel2.setIcon(reelImages.get(1).get(index).getImage());
        reel3.setIcon(reelImages.get(2).get(index).getImage());

        spinButtonVisibility();
        reelClickable = false;
    }


    private void updateLabels() {
        if (slotMachine.getRemCredit() < 10) {
            creditLabel.setText(" 0" + slotMachine.getRemCredit() + " ");
        } else {
            creditLabel.setText(" " + slotMachine.getRemCredit() + " ");
        }
        if (slotMachine.getCurrentBet() < 10) {
            betLabel.setText(" 0" + slotMachine.getCurrentBet() + " ");
        } else {
            betLabel.setText(" " + slotMachine.getCurrentBet() + " ");
        }
    }


    private void addCoinBtnPressed() {
        slotMachine.addCoin();
        updateLabels();
    }

    private void betAddBtnPressed() {
        try {
            slotMachine.betadd();
            updateLabels();
            spinButtonVisibility();
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(null, "Not Enough Credits Available!!");
        }
    }

    private void betSubBtnPressed() {
        try {
            slotMachine.betsub();
            updateLabels();
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(null, "Not Enough Credits Available!!");
        }
    }

    private void resetBtnPressed() {
        slotMachine.setRemCredit(slotMachine.getRemCredit() + slotMachine.getCurrentBet());
        slotMachine.setCurrentBet(0);
        updateLabels();
        spinButtonVisibility();
    }
    
    private void withdrawBtnPressed() {
        slotMachine.setRemCredit(slotMachine.getRemCredit() + slotMachine.getCurrentBet());
        slotMachine.setCurrentBet(0);
        updateLabels();
        spinButtonVisibility();
    }

    private void spinBtnPressed() {
        btn_Spin.setEnabled(false);
        new ThreadController().threadSpinMethod();
        flag = true;
    }


    private void spinButtonVisibility() {
        if (slotMachine.getCurrentBet() == 0) {
            btn_Spin.setEnabled(false);
        } else {
            btn_Spin.setEnabled(true);
        }
    }

    private void turnOffOtherButtonVisibility() {
        btn_AddCoin.setEnabled(false);
        btn_AddBet.setEnabled(false);
        btn_Reset.setEnabled(false);
        btn_Stat.setEnabled(false);
    }

    private void turnOnOtherButtonVisibility() {
        btn_AddCoin.setEnabled(true);
        btn_AddBet.setEnabled(true);
        btn_Reset.setEnabled(true);
        btn_Stat.setEnabled(true);
    }


    private void calculateResult() {
        if (reelClickable) {
            if (reel1.getIcon().toString() == reel2.getIcon().toString()
                    && reel2.getIcon().toString() == reel3.getIcon().toString()
                    && reel1.getIcon().toString() == reel3.getIcon().toString()) {
                profit = ThreadController.reelImages.get(0).get(ThreadController.getIndex()).getValue() * slotMachine.getCurrentBet();
                slotMachine.setRemCredit(slotMachine.getRemCredit()
                        + ThreadController.reelImages.get(0).get(ThreadController.getIndex()).getValue() * slotMachine.getCurrentBet());
                JOptionPane.showMessageDialog(null, "You've Earned: "
                        + ThreadController.reelImages.get(0).get(ThreadController.getIndex()).getValue() * slotMachine.getCurrentBet()
                        + " Credits");

                slotMachine.setCurrentBet(0);
                spinButtonVisibility();
                updateLabels();
                noOfGames++;
                wins++;
            } else if (reel1.getIcon().toString() == reel2.getIcon().toString()
                    || reel2.getIcon().toString() == reel3.getIcon().toString()
                    || reel1.getIcon().toString() == reel3.getIcon().toString()) {
                profit = ThreadController.reelImages.get(0).get(ThreadController.getIndex()).getValue() * slotMachine.getCurrentBet();
                slotMachine.setRemCredit(slotMachine.getRemCredit()
                        + ThreadController.reelImages.get(0).get(ThreadController.getIndex()).getValue() * slotMachine.getCurrentBet());
                JOptionPane.showMessageDialog(null, "You've Earned: "
                        + ThreadController.reelImages.get(0).get(ThreadController.getIndex()).getValue() * slotMachine.getCurrentBet()
                        + " Credits");
                
                slotMachine.setCurrentBet(0);
                spinButtonVisibility();
                updateLabels();
                noOfGames++;
                wins++;

            } else {
                JOptionPane.showMessageDialog(null, "You've Lost!!");
                loss = slotMachine.getCurrentBet();
                slotMachine.setCurrentBet(0);
                spinButtonVisibility();
                updateLabels();
                losses++;
                noOfGames++;
            }

        }
        statValue += profit - loss;
        average = statValue / noOfGames;
        if (noOfGames == 0) {
            average = 0;
        }
        profit = 0;
        loss = 0;
        reelClickable = false;
    }


    private void loadFont() {
        try {
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src/New Athletic M54.ttf")));
        } catch (IOException | FontFormatException e) {
            JOptionPane.showMessageDialog(null, "Unable to load font");
        }
    }


    public static void main(String[] args) {
        SlotMachine slotMachine = new SlotMachine();
        MainGUI gui = new MainGUI(slotMachine);
        gui.setTitle("Slot Machine");
        gui.setLocationRelativeTo(null);
        gui.setVisible(true);

        gui.setMaximumSize(new java.awt.Dimension(720, 600));
        gui.setMinimumSize(new java.awt.Dimension(720, 600));
        gui.setPreferredSize(new java.awt.Dimension(720, 600));
        gui.setResizable(false);
    }

}
