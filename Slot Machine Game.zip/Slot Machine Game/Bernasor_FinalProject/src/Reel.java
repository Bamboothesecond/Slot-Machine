
import javax.swing.*;
import java.util.*;
import java.util.*;

public class Reel {


    private ArrayList<Symbol> symbol = new ArrayList<Symbol>();


    public Reel()
    {
            Symbol bell = new Symbol();
            bell.setImage(new ImageIcon("src/icon/bell.png", "Bell"));
            bell.setValue(6);
            symbol.add(bell);

            Symbol cherry = new Symbol();
            cherry.setImage(new ImageIcon("src/icon/cherry.png", "Cherry"));
            cherry.setValue(2);
            symbol.add(cherry);

            Symbol lemon = new Symbol();
            lemon.setImage(new ImageIcon("src/icon/lemon.png", "Lemon"));
            lemon.setValue(3);
            symbol.add(lemon);

            Symbol plum = new Symbol();
            plum.setImage(new ImageIcon("src/icon/plum.png", "Plum"));
            plum.setValue(4);
            symbol.add(plum);

            Symbol redSeven = new Symbol();
            redSeven.setImage(new ImageIcon("src/icon/redSeven.png", "Seven"));
            redSeven.setValue(7);
            symbol.add(redSeven);

            Symbol watermelon = new Symbol();
            watermelon.setImage(new ImageIcon("src/icon/watermelon.png", "Watermelon"));
            watermelon.setValue(5);
            symbol.add(watermelon);

            Collections.shuffle(symbol);
        }

    public void setSymbol(Symbol symbol) {
        if(symbol != null) {
            this.symbol.add(symbol);
        }
    }

    public ArrayList<Symbol> spin() {
        return symbol;
    }

}
