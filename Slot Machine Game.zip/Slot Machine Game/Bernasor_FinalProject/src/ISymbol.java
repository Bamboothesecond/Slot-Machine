

import javax.swing.ImageIcon;

public interface ISymbol {

    public void setImage(ImageIcon image);

    public ImageIcon getImage();

    public void setValue(int v);

    public int getValue();

}
